#!/bin/sh
# Pencopot Resmi Aplikasi NUSANTARA (nusantara - linux-x86_64)
set -eu

APP_NAME="nusantara"
BIN_NAME="nusantara"
PREFIX="${HOME}/.nusantara"

while [ "$#" -gt 0 ]; do
  case "$1" in
    --prefix)
      shift
      [ "$#" -gt 0 ] || { echo "[GALAT] --prefix memerlukan nilai direktori" >&2; exit 2; }
      PREFIX="$1"
      ;;
    --prefix=*)
      PREFIX="${1#*=}"
      ;;
    -y|--yes|--quiet)
      ;;
    *)
      echo "[GALAT] Opsi tidak dikenal: $1" >&2
      exit 2
      ;;
  esac
  shift
done

rm -f "$PREFIX/bin/$BIN_NAME"
rm -rf "$PREFIX/share/$APP_NAME"
rm -f "$PREFIX/.nusantara-install-$APP_NAME.manifest"

MARKER_BEGIN="# >>> NUSANTARA $APP_NAME PATH >>>"
MARKER_END="# <<< NUSANTARA $APP_NAME PATH <<<"

for rc_cand in "${HOME}/.profile" "${HOME}/.bashrc" "${HOME}/.zshrc"; do
  if [ -f "$rc_cand" ] && grep -Fq "$MARKER_BEGIN" "$rc_cand" 2>/dev/null; then
    TMP_RC="$(mktemp "${TMPDIR:-/tmp}/nusa-rc-XXXXXX")"
    awk -v b="$MARKER_BEGIN" -v e="$MARKER_END" '
      $0 == b { skip=1; next }
      $0 == e { skip=0; next }
      !skip { print }
    ' "$rc_cand" > "$TMP_RC"
    mv -f "$TMP_RC" "$rc_cand"
  fi
done

echo "[SUKSES] $APP_NAME berhasil dicopot dari $PREFIX"
exit 0
