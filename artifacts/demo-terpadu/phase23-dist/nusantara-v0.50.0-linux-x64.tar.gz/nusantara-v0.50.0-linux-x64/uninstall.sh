#!/bin/sh
set -eu

APP_NAME="nusantara"
BIN_NAME="nusantara"
PREFIX="${HOME}/.nusantara"

while [ "$#" -gt 0 ]; do
  case "$1" in
    --prefix)
      shift
      PREFIX="$1"
      ;;
    --prefix=*)
      PREFIX="${1#--prefix=}"
      ;;
    *)
      echo "[GALAT] Opsi tidak dikenali: $1" >&2
      exit 2
      ;;
  esac
  shift
done

rm -f "$PREFIX/bin/$BIN_NAME"
rm -rf "$PREFIX/share/$APP_NAME"

if [ -n "${HOME:-}" ]; then
  for RC in "$HOME/.profile" "$HOME/.bashrc" "$HOME/.zshrc"; do
    if [ -f "$RC" ] && grep -q "# >>> NUSANTARA $APP_NAME >>>" "$RC"; then
      TMP_RC="$RC.tmp.$$"
      sed "/# >>> NUSANTARA $APP_NAME >>>/,/# <<< NUSANTARA $APP_NAME <<</d" "$RC" > "$TMP_RC"
      mv "$TMP_RC" "$RC"
    fi
  done
fi

echo "[OK] $APP_NAME dicopot dari $PREFIX"
