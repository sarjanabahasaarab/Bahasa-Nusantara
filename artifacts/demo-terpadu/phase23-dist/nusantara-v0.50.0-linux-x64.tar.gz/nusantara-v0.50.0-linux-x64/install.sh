#!/bin/sh
# Pemasang Resmi Aplikasi NUSANTARA (nusantara v0.50.0 - linux-x86_64)
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
APP_NAME="nusantara"
APP_VERSION="v0.50.0"
BIN_REL="bin/nusantara"
BIN_NAME="nusantara"
PREFIX="${HOME}/.nusantara"
ADD_PATH=1
QUIET=0

while [ "$#" -gt 0 ]; do
  case "$1" in
    --prefix)
      shift
      [ "$#" -gt 0 ] || { echo "[GALAT] --prefix memerlukan nilai direktori" >&2; exit 2; }
      PREFIX="$1"
      ;;
    --prefix=*)
      PREFIX="${1#*=}"
      ;;
    --no-path)
      ADD_PATH=0
      ;;
    -y|--yes|--quiet)
      QUIET=1
      ;;
    -h|--help)
      echo "Pemakaian: sh install.sh [--prefix <dir>] [--no-path] [-y]"
      exit 0
      ;;
    *)
      echo "[GALAT] Opsi tidak dikenal: $1" >&2
      exit 2
      ;;
  esac
  shift
done

[ -n "$PREFIX" ] || { echo "[GALAT] Prefix tidak boleh kosong" >&2; exit 2; }
[ -f "$SCRIPT_DIR/$BIN_REL" ] || { echo "[GALAT] Biner tidak ditemukan: $SCRIPT_DIR/$BIN_REL" >&2; exit 1; }
[ -f "$SCRIPT_DIR/SHA256SUMS" ] || { echo "[GALAT] Berkas integritas SHA256SUMS tidak ditemukan" >&2; exit 1; }

compute_sha256() {
  if command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$1" | awk '{print tolower($1)}'
  elif command -v shasum >/dev/null 2>&1; then
    shasum -a 256 "$1" | awk '{print tolower($1)}'
  elif command -v openssl >/dev/null 2>&1; then
    openssl dgst -sha256 "$1" | awk '{print tolower($NF)}'
  else
    echo "[GALAT] Tidak ada utilitas sha256sum/shasum/openssl di sistem." >&2
    return 1
  fi
}

# Verifikasi SHA256SUMS sebelum memodifikasi target prefix
VERIFIED_COUNT=0
while IFS= read -r line || [ -n "$line" ]; do
  [ -n "$line" ] || continue
  EXPECTED_HASH="$(printf '%s' "$line" | awk '{print tolower($1)}')"
  REL_FILE="$(printf '%s' "$line" | sed -e 's/^[0-9a-fA-F]*[[:space:]]*//' -e 's/^\*//')"
  [ -n "$EXPECTED_HASH" ] && [ -n "$REL_FILE" ] || continue
  TARGET_PATH="$SCRIPT_DIR/$REL_FILE"
  if [ ! -f "$TARGET_PATH" ]; then
    echo "[GALAT] Berkas paket hilang saat verifikasi checksum: $REL_FILE" >&2
    exit 1
  fi
  ACTUAL_HASH="$(compute_sha256 "$TARGET_PATH")"
  if [ "$ACTUAL_HASH" != "$EXPECTED_HASH" ]; then
    echo "[GALAT] Checksum SHA-256 tidak cocok untuk $REL_FILE (diharapkan=$EXPECTED_HASH, aktual=$ACTUAL_HASH)" >&2
    exit 1
  fi
  VERIFIED_COUNT=$((VERIFIED_COUNT + 1))
done < "$SCRIPT_DIR/SHA256SUMS"

if [ "$VERIFIED_COUNT" -le 0 ]; then
  echo "[GALAT] SHA256SUMS kosong atau tidak memverifikasi berkas apa pun." >&2
  exit 1
fi

BACKUP_DIR="$(mktemp -d "${TMPDIR:-/tmp}/nusa-install-backup-XXXXXX")"
INSTALLED_BIN="$PREFIX/bin/$BIN_NAME"
INSTALLED_MANIFEST="$PREFIX/share/$APP_NAME/manifest.json"
RECEIPT_FILE="$PREFIX/.nusantara-install-$APP_NAME.manifest"

TMP_BIN=""
cleanup_on_fail() {
  rc="$?"
  if [ "$rc" -ne 0 ]; then
    echo "[PERINGATAN] Instalasi gagal, melakukan rollback atomik..." >&2
    if [ -n "$TMP_BIN" ]; then
      rm -f "$TMP_BIN" 2>/dev/null || true
    fi
    if [ -f "$BACKUP_DIR/prev_bin" ]; then
      cp -f "$BACKUP_DIR/prev_bin" "$INSTALLED_BIN" 2>/dev/null || true
    else
      rm -f "$INSTALLED_BIN" 2>/dev/null || true
    fi
    if [ -f "$BACKUP_DIR/prev_manifest" ]; then
      cp -f "$BACKUP_DIR/prev_manifest" "$INSTALLED_MANIFEST" 2>/dev/null || true
    else
      rm -f "$INSTALLED_MANIFEST" 2>/dev/null || true
    fi
  fi
  rm -rf "$BACKUP_DIR"
  exit "$rc"
}
trap cleanup_on_fail EXIT HUP INT TERM

mkdir -p "$PREFIX/bin" "$PREFIX/lib" "$PREFIX/share/$APP_NAME"
if [ -f "$INSTALLED_BIN" ]; then
  cp -f "$INSTALLED_BIN" "$BACKUP_DIR/prev_bin"
fi
if [ -f "$INSTALLED_MANIFEST" ]; then
  cp -f "$INSTALLED_MANIFEST" "$BACKUP_DIR/prev_manifest"
fi

TMP_BIN="$PREFIX/bin/.$BIN_NAME.tmp.$$"
cp -f "$SCRIPT_DIR/$BIN_REL" "$TMP_BIN"
chmod 755 "$TMP_BIN"
mv -f "$TMP_BIN" "$INSTALLED_BIN"
TMP_BIN=""

if [ -d "$SCRIPT_DIR/lib" ]; then
  for f in "$SCRIPT_DIR/lib/"*; do
    [ -e "$f" ] || continue
    cp -f "$f" "$PREFIX/lib/"
  done
fi

if [ -f "$SCRIPT_DIR/manifest.json" ]; then
  if [ -d "$INSTALLED_MANIFEST" ]; then
    echo "[GALAT] Jalur tujuan manifest.json adalah direktori: $INSTALLED_MANIFEST" >&2
    exit 1
  fi
  cp -f "$SCRIPT_DIR/manifest.json" "$INSTALLED_MANIFEST"
fi

if [ -f "$SCRIPT_DIR/uninstall.sh" ]; then
  DEST_UNINSTALL="$PREFIX/share/$APP_NAME/uninstall.sh"
  if [ -d "$DEST_UNINSTALL" ]; then
    echo "[GALAT] Jalur tujuan uninstall.sh adalah direktori: $DEST_UNINSTALL" >&2
    exit 1
  fi
  cp -f "$SCRIPT_DIR/uninstall.sh" "$DEST_UNINSTALL"
  chmod 755 "$DEST_UNINSTALL"
fi

RC_UPDATED=""
if [ "$ADD_PATH" -eq 1 ]; then
  PATH_LINE="export PATH=\"$PREFIX/bin:\$PATH\""
  for rc_cand in "${HOME}/.profile" "${HOME}/.bashrc" "${HOME}/.zshrc"; do
    if [ -f "$rc_cand" ] || [ "$rc_cand" = "${HOME}/.profile" ]; then
      MARKER_BEGIN="# >>> NUSANTARA $APP_NAME PATH >>>"
      MARKER_END="# <<< NUSANTARA $APP_NAME PATH <<<"
      if ! grep -Fq "$MARKER_BEGIN" "$rc_cand" 2>/dev/null; then
        printf '\n%s\n%s\n%s\n' "$MARKER_BEGIN" "$PATH_LINE" "$MARKER_END" >> "$rc_cand"
        RC_UPDATED="$RC_UPDATED $rc_cand"
      fi
    fi
  done
fi

cat > "$RECEIPT_FILE" <<EOF
{
  "appName": "$APP_NAME",
  "appVersion": "$APP_VERSION",
  "target": "linux-x86_64",
  "prefix": "$PREFIX",
  "installedBin": "$INSTALLED_BIN",
  "installedManifest": "$INSTALLED_MANIFEST",
  "rcFiles": "$RC_UPDATED"
}
EOF

trap - EXIT HUP INT TERM
rm -rf "$BACKUP_DIR"

if [ "$QUIET" -eq 0 ]; then
  echo "[SUKSES] $APP_NAME ($APP_VERSION) berhasil dipasang di: $INSTALLED_BIN"
fi
exit 0
