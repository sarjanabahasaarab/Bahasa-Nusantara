#!/bin/sh
set -eu

APP_NAME="nusantara"
APP_VERSION="v0.50.0"
BIN_REL="bin/nusantara"
BIN_NAME="nusantara"
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
PREFIX="${HOME}/.nusantara"
NO_PATH_UPDATE=0

while [ "$#" -gt 0 ]; do
  case "$1" in
    --prefix)
      shift
      PREFIX="$1"
      ;;
    --prefix=*)
      PREFIX="${1#--prefix=}"
      ;;
    --no-path)
      NO_PATH_UPDATE=1
      ;;
    *)
      echo "[GALAT] Opsi tidak dikenali: $1" >&2
      exit 2
      ;;
  esac
  shift
done

verify_sha256() {
  SUM_FILE="$SCRIPT_DIR/SHA256SUMS"
  [ -f "$SUM_FILE" ] || { echo "[GALAT] SHA256SUMS tidak ditemukan." >&2; return 1; }
  while IFS= read -r line || [ -n "$line" ]; do
    [ -z "$line" ] && continue
    EXPECTED="$(printf '%s' "$line" | awk '{print $1}')"
    REL_FILE="$(printf '%s' "$line" | sed 's/^[0-9a-fA-F]*[[:space:]]*\*\{0,1\}//')"
    [ -z "$REL_FILE" ] && continue
    TARGET_FILE="$SCRIPT_DIR/$REL_FILE"
    [ -f "$TARGET_FILE" ] || { echo "[GALAT] Berkas paket hilang: $REL_FILE" >&2; return 1; }
    if command -v sha256sum >/dev/null 2>&1; then
      ACTUAL="$(sha256sum "$TARGET_FILE" | awk '{print $1}')"
    elif command -v shasum >/dev/null 2>&1; then
      ACTUAL="$(shasum -a 256 "$TARGET_FILE" | awk '{print $1}')"
    else
      ACTUAL="$(openssl dgst -sha256 "$TARGET_FILE" | awk '{print $NF}')"
    fi
    if [ "$ACTUAL" != "$EXPECTED" ]; then
      echo "[GALAT] Checksum SHA-256 tidak cocok untuk $REL_FILE (diharapkan $EXPECTED, aktual $ACTUAL)" >&2
      return 1
    fi
  done < "$SUM_FILE"
  return 0
}

verify_sha256

mkdir -p "$PREFIX/bin" "$PREFIX/lib" "$PREFIX/share/$APP_NAME"
BACKUP_BIN=""
DEST_BIN="$PREFIX/bin/$BIN_NAME"
if [ -f "$DEST_BIN" ]; then
  BACKUP_BIN="$DEST_BIN.bak.$$"
  cp "$DEST_BIN" "$BACKUP_BIN"
fi

if ! cp "$SCRIPT_DIR/$BIN_REL" "$DEST_BIN"; then
  if [ -n "$BACKUP_BIN" ] && [ -f "$BACKUP_BIN" ]; then
    mv "$BACKUP_BIN" "$DEST_BIN"
  fi
  echo "[GALAT] Instalasi gagal; rollback otomatis selesai." >&2
  exit 1
fi
chmod 755 "$DEST_BIN"
[ -n "$BACKUP_BIN" ] && rm -f "$BACKUP_BIN"

if [ -d "$SCRIPT_DIR/lib" ]; then
  for f in "$SCRIPT_DIR/lib"/*; do
    [ -e "$f" ] || continue
    cp "$f" "$PREFIX/lib/"
  done
fi

RECEIPT="$PREFIX/share/$APP_NAME/install-receipt.json"
printf '{\n  "appName": "%s",\n  "appVersion": "%s",\n  "prefix": "%s",\n  "binary": "%s"\n}\n' \
  "$APP_NAME" "$APP_VERSION" "$PREFIX" "$DEST_BIN" > "$RECEIPT"

if [ "$NO_PATH_UPDATE" -eq 0 ] && [ -n "${HOME:-}" ]; then
  for RC in "$HOME/.profile" "$HOME/.bashrc" "$HOME/.zshrc"; do
    if [ -f "$RC" ] && ! grep -q "# >>> NUSANTARA $APP_NAME >>>" "$RC"; then
      printf '\n# >>> NUSANTARA %s >>>\nexport PATH="%s/bin:$PATH"\n# <<< NUSANTARA %s <<<\n' \
        "$APP_NAME" "$PREFIX" "$APP_NAME" >> "$RC"
    fi
  done
fi

echo "[OK] $APP_NAME $APP_VERSION terpasang di $DEST_BIN"
